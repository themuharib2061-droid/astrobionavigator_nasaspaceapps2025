import 'dart:convert';
import 'package:http/http.dart' as http;

import '../models/study_model.dart';

class StudyApi {
  // TODO: set your real base URL
  static const String baseUrl = 'https://your-backend.example.com';

  static Uri _trendingUri({
    String query = '',
    int? year,
    String? category,
    int page = 1,
    int pageSize = 10,
  }) {
    final qp = <String, String>{
      'page': '$page',
      'pageSize': '$pageSize',
    };
    if (query.isNotEmpty) qp['q'] = query;
    if (year != null) qp['year'] = '$year';
    if (category != null && category.isNotEmpty) qp['category'] = category;

    return Uri.parse('$baseUrl/api/trending').replace(queryParameters: qp);
  }

  static Future<List<Study>> fetchTrending({
    String query = '',
    int? year,
    String? category,
    int page = 1,
    int pageSize = 10,
  }) async {
    final uri = _trendingUri(
      query: query,
      year: year,
      category: category,
      page: page,
      pageSize: pageSize,
    );

    final res = await http.get(uri, headers: const {
      'Accept': 'application/json',
    });

    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('Failed to load studies (HTTP ${res.statusCode})');
    }

    final decoded = jsonDecode(res.body);
    final Map<String, dynamic> data =
    decoded is Map<String, dynamic> ? decoded : <String, dynamic>{};

    final List items = (data['items'] as List?) ?? const [];
    return items
        .map((e) => Study.fromJson(e as Map<String, dynamic>))
        .toList();
  }
}
