import 'dart:convert';
import 'package:http/http.dart' as http;

class SummaryChatApi {
  static const String baseUrl = 'https://astro-bio-navigator-server.vercel.app/api';

  static Future<String> summarizeUrl(String url) async {
    final res = await http.post(
      Uri.parse('$baseUrl/summarize'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'url': url}),
    );
    if (res.statusCode != 200) {
      throw Exception('Summarize failed (HTTP ${res.statusCode}): ${res.body}');
    }
    final data = jsonDecode(res.body);
    if (data is Map && data['success'] == true && data['summary'] != null) {
      return data['summary'].toString();
    }
    throw Exception('Summarize failed: ${data['error'] ?? 'Unknown error'}');
  }
}
