// lib/services/favorites_service.dart
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'paper_service.dart'; // for Paper model (title, link, pdfLink, authors, publishYear)

/// Basic DTO for a saved article.
/// Stored in SharedPreferences as a JSON list.
class FavoriteItem {
  final String id;             // unique key (prefer pdfLink/link; fallback title)
  final String title;
  final String? url;           // best openable url (pdfLink first, else link)
  final String? year;          // string form (e.g., "2024")
  final List<String> authors;
  final String? link;          // raw link if available
  final String? pdfLink;       // raw pdfLink if available

  FavoriteItem({
    required this.id,
    required this.title,
    this.url,
    this.year,
    this.authors = const [],
    this.link,
    this.pdfLink,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'url': url,
    'year': year,
    'authors': authors,
    'link': link,
    'pdfLink': pdfLink,
  };

  factory FavoriteItem.fromJson(Map<String, dynamic> j) => FavoriteItem(
    id: (j['id'] ?? j['url'] ?? j['pdfLink'] ?? j['link'] ?? '').toString(),
    title: (j['title'] ?? '').toString(),
    url: j['url']?.toString() ??
        j['pdfLink']?.toString() ??
        j['link']?.toString(),
    year: j['year']?.toString() ?? j['publishYear']?.toString(),
    authors: j['authors'] is List
        ? (j['authors'] as List)
        .where((e) => e != null)
        .map((e) => e.toString())
        .toList()
        : (j['authors'] == null
        ? <String>[]
        : j['authors']
        .toString()
        .split(',')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList()),
    link: j['link']?.toString(),
    pdfLink: j['pdfLink']?.toString(),
  );

  /// Build from your Paper model.
  static FavoriteItem fromPaper(Paper p) {
    final best = (p.pdfLink != null && p.pdfLink!.trim().isNotEmpty)
        ? p.pdfLink!.trim()
        : p.link.trim();
    final authorsStr = p.authors; // Paper.authors is a single string
    final authorsList = authorsStr.isEmpty
        ? <String>[]
        : authorsStr.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();

    return FavoriteItem(
      id: best.isNotEmpty ? best : p.title,
      title: p.title,
      url: best.isNotEmpty ? best : null,
      year: p.publishYear?.toString(),
      authors: authorsList,
      link: p.link,
      pdfLink: p.pdfLink,
    );
  }
}

class FavoritesService {
  FavoritesService._();
  static final FavoritesService instance = FavoritesService._();

  /// Back-compat alias so existing code `FavoritesService.I` compiles.
  static FavoritesService get I => instance;

  /// Live list for ValueListenableBuilder in SavedArticlesPage.
  final ValueNotifier<List<FavoriteItem>> favorites =
  ValueNotifier<List<FavoriteItem>>(<FavoriteItem>[]);

  static const _storeKey = 'saved_articles_v1';
  bool _loaded = false;

  /// Call this once on app start (e.g., in main()).
  Future<void> init() async {
    await _ensureLoaded();
  }

  // ----------------- Public API used by your UI -----------------

  Future<bool> isSavedByUrl(String url) async {
    await _ensureLoaded();
    final u = url.trim();
    return favorites.value.any(
          (f) => f.url == u || f.id == u || f.link == u || f.pdfLink == u,
    );
  }

  Future<void> savePaper(Paper p) async {
    await _ensureLoaded();
    final item = FavoriteItem.fromPaper(p);
    final exists = favorites.value
        .any((f) => f.id == item.id || f.url == item.url);
    if (exists) return;
    favorites.value = [item, ...favorites.value];
    await _persist();
  }

  Future<void> removeByUrl(String url) async {
    await _ensureLoaded();
    final u = url.trim();
    favorites.value = favorites.value
        .where((f) =>
    f.url != u && f.id != u && f.link != u && f.pdfLink != u)
        .toList();
    await _persist();
  }

  /// Old helper your Saved page calls from the delete icon.
  /// If the item exists → remove; otherwise add a minimal item.
  Future<void> toggleFromFields({
    required String id,
    required String title,
    String? url,
    String? year,
    List<String>? authors,
  }) async {
    await _ensureLoaded();

    final key = (url?.trim().isNotEmpty == true) ? url!.trim() : id.trim();
    final idx =
    favorites.value.indexWhere((f) => f.id == key || f.url == key);

    if (idx >= 0) {
      final copy = [...favorites.value]..removeAt(idx);
      favorites.value = copy;
      await _persist();
      return;
    }

    final item = FavoriteItem(
      id: key.isNotEmpty ? key : title,
      title: title,
      url: url?.trim().isNotEmpty == true ? url!.trim() : null,
      year: year,
      authors: authors ?? <String>[],
      link: url,
      pdfLink: null,
    );
    favorites.value = [item, ...favorites.value];
    await _persist();
  }

  // ----------------- Internal storage helpers -----------------

  Future<void> _ensureLoaded() async {
    if (_loaded) return;
    final sp = await SharedPreferences.getInstance();
    final raw = sp.getString(_storeKey);
    if (raw != null && raw.isNotEmpty) {
      final data = jsonDecode(raw);
      if (data is List) {
        favorites.value = data.map<FavoriteItem>((e) {
          final m = e is Map<String, dynamic>
              ? e
              : Map<String, dynamic>.from(e as Map);
          return FavoriteItem.fromJson(m);
        }).toList();
      }
    }
    _loaded = true;
  }

  Future<void> _persist() async {
    final sp = await SharedPreferences.getInstance();
    final list = favorites.value.map((e) => e.toJson()).toList();
    await sp.setString(_storeKey, jsonEncode(list));
  }
}
