// lib/services/paper_service.dart
// Complete PaperService + models/mappers (search + trending)
// - Robust JSON parsing (authors array/string, year int?)
// - Matches your server keys: title, link, abstract, authors, publishYear, publicationInfo, pdfLink
// - Adds a PaperX extension with bestUrl (prefers pdfLink, falls back to link)

import 'dart:convert';
import 'package:http/http.dart' as http;

class PaperService {
  static const String baseUrl = 'https://astro-bio-navigator-server.vercel.app/api';
  static const Map<String, String> _headers = {'Content-Type': 'application/json'};

  /// POST /api/search-papers
  Future<List<Paper>> searchPapers({
    required String keyword,
    int limit = 10,
    http.Client? client,
  }) async {
    final uri = Uri.parse('$baseUrl/search-papers');
    final body = jsonEncode({'keyword': keyword, 'limit': limit});
    final res = await (client ?? http.Client())
        .post(uri, headers: _headers, body: body)
        .timeout(const Duration(seconds: 30));

    if (res.statusCode != 200) {
      throw Exception('Failed to fetch papers (HTTP ${res.statusCode})');
    }

    final data = _decodeJson(res.body);
    if (data['success'] == true && data['papers'] is List) {
      final list = (data['papers'] as List).map((e) => Paper.fromJson(_asMap(e))).toList();
      return list;
    }
    throw Exception(data['error']?.toString() ?? 'Unknown error from /search-papers');
  }

  /// POST /api/trending-papers-by-keywords
  Future<List<TrendingPaper>> trendingPapersByKeywords({
    required List<String> keywords,
    int limit = 3,
    int yearFrom = 2020,
    http.Client? client,
  }) async {
    final uri = Uri.parse('$baseUrl/trending-papers-by-keywords');
    final body = jsonEncode({
      'keywords': keywords,
      'limit': limit,
      'yearFrom': yearFrom,
    });
    final res = await (client ?? http.Client())
        .post(uri, headers: _headers, body: body)
        .timeout(const Duration(seconds: 30));

    if (res.statusCode != 200) {
      throw Exception('Failed to fetch trending papers (HTTP ${res.statusCode})');
    }

    final data = _decodeJson(res.body);
    if (data['success'] == true && data['results'] is List) {
      final list = (data['results'] as List)
          .map((e) => TrendingPaper.fromJson(_asMap(e)))
          .toList();
      return list;
    }
    throw Exception(data['error']?.toString() ?? 'Unknown error from /trending-papers-by-keywords');
  }

  // -------------------- helpers --------------------

  static Map<String, dynamic> _decodeJson(String s) {
    final dynamic v = jsonDecode(s);
    return _asMap(v);
  }

  static Map<String, dynamic> _asMap(dynamic v) {
    if (v is Map<String, dynamic>) return v;
    if (v is Map) return v.map((k, v) => MapEntry(k.toString(), v));
    return <String, dynamic>{};
  }
}

// ==================== Models / Mappers ====================

class Paper {
  final String title;
  final String link;            // paper page
  final String abstract;        // server key: 'abstract'
  final String authors;         // joined string if server sends a List
  final int? publishYear;       // parsed to int?
  final String publicationInfo;
  final String? pdfLink;        // direct PDF if available

  const Paper({
    required this.title,
    required this.link,
    required this.abstract,
    required this.authors,
    required this.publishYear,
    required this.publicationInfo,
    this.pdfLink,
  });

  factory Paper.fromJson(Map<String, dynamic> json) {
    // authors may be string or List<String>
    final a = json['authors'];
    final authorsStr = a is List
        ? a.where((e) => e != null).map((e) => e.toString()).join(', ')
        : (a ?? '').toString();

    // publishYear may be int or string
    final y = json['publishYear'];
    final yearInt = (y is int) ? y : int.tryParse('${y ?? ''}');

    return Paper(
      title: (json['title'] ?? '').toString(),
      link: (json['link'] ?? '').toString(),
      abstract: (json['abstract'] ?? '').toString(),
      authors: authorsStr,
      publishYear: yearInt,
      publicationInfo: (json['publicationInfo'] ?? '').toString(),
      pdfLink: json['pdfLink']?.toString(),
    );
  }
}

class TrendingPaper {
  final String keyword;
  final List<Paper> papers;

  const TrendingPaper({
    required this.keyword,
    required this.papers,
  });

  factory TrendingPaper.fromJson(Map<String, dynamic> json) {
    final raw = json['papers'];
    final list = (raw is List ? raw : const [])
        .map((e) => Paper.fromJson(PaperService._asMap(e)))
        .toList();

    return TrendingPaper(
      keyword: (json['keyword'] ?? '').toString(),
      papers: list,
    );
  }
}

// ==================== Convenience Extension ====================

extension PaperX on Paper {
  /// Prefer direct PDF; fall back to the paper page.
  String? get bestUrl {
    if (pdfLink != null && pdfLink!.trim().isNotEmpty) return pdfLink;
    if (link.trim().isNotEmpty) return link;
    return null;
  }
}
