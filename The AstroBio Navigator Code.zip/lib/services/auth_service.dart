// lib/services/auth_service.dart
import 'dart:typed_data';
import 'package:supabase_flutter/supabase_flutter.dart';

final _supa = Supabase.instance.client;

/// Auth + Profile service using Supabase.
/// - Step 1: signUpStep1 → creates auth user + inserts `profiles` row
/// - Step 2: completeSignupStep2 → uploads avatar (optional) + updates `profiles`
/// - Login/Logout: signIn / signOut
/// - Profile stream: profileStream(uid)
class AuthService {
  // ADD inside class AuthService

  /// Save the user's top-3 preferred categories
  static Future<void> setPreferredCategories({
    required String uid,
    required List<String> categories, // must be length <= 3
  }) async {
    if (categories.length > 3) {
      throw ArgumentError('You can select at most 3 categories.');
    }
    await _supa.from('profiles').update({
      'preferred_categories': categories,
      'updated_at': DateTime.now().toIso8601String(),
    }).eq('id', uid);
  }

  /// STEP 1: Create account and write initial profile row.
  /// Returns the created Supabase `User`.
  ///
  /// If email confirmation is enabled in your project, this may throw
  /// "Check your email to confirm." because there is no active session yet.
  static Future<User> signUpStep1({
    required String name,
    required String email,
    required String password,
  }) async {
    final res = await _supa.auth.signUp(
      email: email,
      password: password,
      data: {'display_name': name},
      emailRedirectTo: null, // add deep link if using confirm email
    );

    final user = res.user;
    if (user == null) {
      throw AuthException('Check your email to confirm the account.');
    }

    // Insert a new profile row (id must equal auth.users.id)
    // If this row might already exist, you can use upsert via RPC or handle conflict with try/catch.
    await _supa.from('profiles').insert({
      'id': user.id,
      'email': email,
      'display_name': name,
      'preferred_categories': <String>[],
      'created_at': DateTime.now().toIso8601String(),
      'updated_at': DateTime.now().toIso8601String(),
    });

    return user;
  }

  /// STEP 2: Upload avatar (optional) to Storage bucket `avatars` and update profile.
  /// If the file already exists, we overwrite it via updateBinary; if that fails we remove & upload again.
  static Future<void> completeSignupStep2({
    required String uid,
    String? country,
    Uint8List? avatarBytes,
  }) async {
    String? publicUrl;

    if (avatarBytes != null) {
      final bucket = _supa.storage.from('avatars');
      final path = '$uid.jpg';

      // Try upload; if exists, update; if update fails, remove then upload.
      try {
        await bucket.uploadBinary(
          path,
          avatarBytes,
          fileOptions: const FileOptions(contentType: 'image/jpeg'),
        );
      } catch (_) {
        try {
          await bucket.updateBinary(
            path,
            avatarBytes,
            fileOptions: const FileOptions(contentType: 'image/jpeg'),
          );
        } catch (_) {
          try {
            await bucket.remove([path]);
            await bucket.uploadBinary(
              path,
              avatarBytes,
              fileOptions: const FileOptions(contentType: 'image/jpeg'),
            );
          } catch (e) {
            rethrow;
          }
        }
      }

      publicUrl = bucket.getPublicUrl(path);
    }

    await _supa.from('profiles').update({
      if (country != null) 'country': country,
      if (publicUrl != null) 'avatar_url': publicUrl,
      'updated_at': DateTime.now().toIso8601String(),
    }).eq('id', uid);
  }

  /// Email + password sign-in.
  static Future<void> signIn(String email, String password) async {
    await _supa.auth.signInWithPassword(email: email, password: password);
  }

  /// Sign out.
  static Future<void> signOut() => _supa.auth.signOut();

  /// Stream a single profile row for the current user.
  static Stream<Map<String, dynamic>?> profileStream(String uid) {
    return _supa
        .from('profiles')
        .stream(primaryKey: ['id'])
        .eq('id', uid)
        .map((rows) => rows.isNotEmpty ? rows.first : null);
  }

  /// Convenience getter for current user id.
  static String? get currentUserId => _supa.auth.currentUser?.id;
}
