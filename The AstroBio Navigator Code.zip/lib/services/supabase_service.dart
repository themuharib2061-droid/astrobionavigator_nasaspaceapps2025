import 'dart:typed_data';
import 'package:supabase_flutter/supabase_flutter.dart';

final supa = Supabase.instance.client;

class SupaAuth {
  /// STEP 1: create auth user and insert profile row
  static Future<User> signUpStep1({
    required String name,
    required String email,
    required String password,
  }) async {
    final res = await supa.auth.signUp(
      email: email,
      password: password,
      data: {'display_name': name},
      emailRedirectTo: null, // optional; add deep link if using email confirm
    );

    final user = res.user;
    final session = res.session;

    // If email confirmation is ON, session may be null
    if (user == null) {
      throw AuthException('Check your email to confirm the account.');
    }

    // Insert a profile row (id must equal auth user id)
    await supa.from('profiles').insert({
      'id': user.id,
      'email': email,
      'display_name': name,
    });

    // If you need the user immediately signed in but confirmation is on,
    // switch off confirmations for dev, or implement a "Verify email" screen.
    if (session == null) {
      // still fine; step 2 will require re-login after email confirmation
    }
    return user;
  }

  /// STEP 2: upload avatar (optional) + update country
  static Future<void> completeSignupStep2({
    required String uid,
    String? country,
    Uint8List? avatarBytes,
  }) async {
    String? publicUrl;

    if (avatarBytes != null) {
      final path = '$uid.jpg';
      await supa.storage.from('avatars').uploadBinary(
        path,
        avatarBytes,
        fileOptions: const FileOptions(
          contentType: 'image/jpeg',
          upsert: true,
        ),
      );
      publicUrl = supa.storage.from('avatars').getPublicUrl(path);
    }

    await supa.from('profiles').update({
      'country': country,
      if (publicUrl != null) 'avatar_url': publicUrl,
      'updated_at': DateTime.now().toIso8601String(),
    }).eq('id', uid);
  }

  static Future<void> signIn(String email, String password) async {
    await supa.auth.signInWithPassword(email: email, password: password);
  }

  static Future<void> signOut() => supa.auth.signOut();

  // Stream the current user's profile
  static Stream<Map<String, dynamic>?> profileStream(String uid) {
    return supa
        .from('profiles')
        .stream(primaryKey: ['id'])
        .eq('id', uid)
        .map((rows) => rows.isNotEmpty ? rows.first : null);
  }
}
