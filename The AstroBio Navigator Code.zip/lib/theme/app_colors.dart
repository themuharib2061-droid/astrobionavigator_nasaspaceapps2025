import 'package:flutter/material.dart';

class AppColors {
  // Dark theme (from your screenshot)
  static const bg            = Color(0xFF0A101F);
  static const surface       = Color(0xFF111A29);
  static const surfaceAlt    = Color(0xFF202124);
  static const outline       = Color(0xFF2E3133);

  static const textPrimary   = Color(0xFFE6EAF2);
  static const textSecondary = Color(0xFF9AA4B2);
  static const iconMuted     = Color(0xFF4C566A);

  static const accent        = Color(0xFF04A6C7);

  static const chipBg        = surfaceAlt;
  static const chipBorder    = outline;
  static const chipText      = textPrimary;
  static const lightText = Color(0xFF8F9BB3); // <— add this if missing
  static const cardBackground = Color(0xFF171E31);
  static const darkText   = Color(0xFF4A4A4A); // <-- add this
}
