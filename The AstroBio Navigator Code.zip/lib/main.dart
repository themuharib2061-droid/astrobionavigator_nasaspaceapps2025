// lib/main.dart
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'services/favorites_service.dart' show FavoritesService;
import 'theme/app_colors.dart';
import 'screens/login_page.dart';
import 'screens/main_screen.dart';

Future<void> main() async {

  WidgetsFlutterBinding.ensureInitialized();
  await FavoritesService.instance.init();  // now defined
  // ⛔️ REPLACE THESE WITH YOUR REAL VALUES
  const supabaseUrl = 'https://gvxaanclpeyqtsauktpd.supabase.co'; // no trailing slash
  const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd2eGFhbmNscGV5cXRzYXVrdHBkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk0MTgzNDcsImV4cCI6MjA3NDk5NDM0N30.CGn-k9jNhDMiVKkALolWj8faQ5HII8xPeWSB7rgNWMY';

  await Supabase.initialize(
    url: supabaseUrl,
    anonKey: supabaseAnonKey,
  );

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AstroBio Navigator',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColors.bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppColors.accent,
          brightness: Brightness.dark,
          primary: AppColors.accent,
          surface: AppColors.surface,
        ),
      ),
      home: const _AuthGate(),
    );
  }
}

class _AuthGate extends StatelessWidget {
  const _AuthGate({super.key});
  @override
  Widget build(BuildContext context) {
    final session = Supabase.instance.client.auth.currentSession;
    return session == null ? const LoginPage() : const MainScreen();
  }
}
