// lib/models/study_model.dart
class Study {
  final String title;
  final String? link;     // paper page (fallback)
  final String? pdfLink;  // direct PDF if available
  final String authors;
  final int? year;
  final String? publicationInfo;

  Study({
    required this.title,
    required this.authors,
    this.year,
    this.publicationInfo,
    this.link,
    this.pdfLink,
  });

  factory Study.fromJson(Map<String, dynamic> j) => Study(
    title: (j['title'] ?? '').toString(),
    authors: (j['authors'] ?? '').toString(),
    year: j['publishYear'] is int ? j['publishYear'] as int : int.tryParse('${j['publishYear']}'),
    publicationInfo: j['publicationInfo']?.toString(),
    link: j['link']?.toString(),
    pdfLink: j['pdfLink']?.toString(),
  );
}
