// lib/models/study_compat.dart
// Safe accessors for different Study shapes without changing your model.

extension StudyCompat on Object {
  /// Title is required in your app; fall back to empty if missing.
  String get studyTitle {
    final o = this as dynamic;
    try { final v = (o.title as String?); if (v != null && v.isNotEmpty) return v; } catch (_) {}
    try { final v = (o.name  as String?); if (v != null && v.isNotEmpty) return v; } catch (_) {}
    return "";
  }

  /// Abstract/description text (best-effort).
  String get studyBlurb {
    final o = this as dynamic;
    try { final v = (o.abstractText as String?); if (_nz(v)) return v!; } catch (_) {}
    try { final v = (o.abstract     as String?); if (_nz(v)) return v!; } catch (_) {}
    try { final v = (o.summary      as String?); if (_nz(v)) return v!; } catch (_) {}
    try { final v = (o.description  as String?); if (_nz(v)) return v!; } catch (_) {}
    try { final v = (o.snippet      as String?); if (_nz(v)) return v!; } catch (_) {}
    return "";
  }

  /// Canonical URL to open/summarize (tries many common field names).
  String? get studyUrl {
    final o = this as dynamic;
    try { final v = (o.url        as String?); if (_nz(v)) return v; } catch (_) {}
    try { final v = (o.link       as String?); if (_nz(v)) return v; } catch (_) {}
    try { final v = (o.paperUrl   as String?); if (_nz(v)) return v; } catch (_) {}
    try { final v = (o.sourceUrl  as String?); if (_nz(v)) return v; } catch (_) {}
    try { final v = (o.openUrl    as String?); if (_nz(v)) return v; } catch (_) {}
    try { final v = (o.htmlUrl    as String?); if (_nz(v)) return v; } catch (_) {}
    try { final v = (o.pdfUrl     as String?); if (_nz(v)) return v; } catch (_) {}
    return null;
  }
}

bool _nz(String? s) => s != null && s.trim().isNotEmpty;
