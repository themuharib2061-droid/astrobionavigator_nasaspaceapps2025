// lib/screens/saved_articles_page.dart
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/favorites_service.dart';
import '../theme/app_colors.dart';

class SavedArticlesPage extends StatelessWidget {
  const SavedArticlesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Saved Articles')),
      body: ValueListenableBuilder<List<FavoriteItem>>(   // ← body, not child
        valueListenable: FavoritesService.I.favorites,    // I now exists (alias)
        builder: (context, items, _) {
          if (items.isEmpty) {
            return const _EmptyState();
          }

          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, i) {
              final f = items[i];

              return Card(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Title + remove
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Text(
                              f.title,
                              style: Theme.of(context).textTheme.titleMedium,
                            ),
                          ),
                          IconButton(
                            tooltip: 'Remove from saved',
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () => FavoritesService.I.toggleFromFields(
                              id: f.id,
                              title: f.title,
                              url: f.url,
                              year: f.year,
                              authors: f.authors,
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 8),

                      // Year chip + Authors button
                      Row(
                        children: [
                          if (f.year != null && f.year!.isNotEmpty)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(18),
                                color: Theme.of(context)
                                    .colorScheme
                                    .surfaceVariant,
                              ),
                              child: Text(f.year!),
                            ),
                          const SizedBox(width: 10),
                          OutlinedButton(
                            onPressed: f.authors.isEmpty
                                ? null
                                : () {
                              showDialog(
                                context: context,
                                builder: (_) => AlertDialog(
                                  title: const Text('Authors'),
                                  content: Text(f.authors.join(', ')),
                                  actions: [
                                    TextButton(
                                      onPressed: () =>
                                          Navigator.pop(context),
                                      child: const Text('Close'),
                                    ),
                                  ],
                                ),
                              );
                            },
                            child: const Text('Authors'),
                          ),
                        ],
                      ),

                      const SizedBox(height: 12),

                      // Actions row: only "Open Paper" on Saved page
                      Row(
                        children: [
                          TextButton.icon(
                            onPressed: f.url == null
                                ? null
                                : () async {
                              final uri = _normalizeUrl(f.url!);
                              final ok = await launchUrl(
                                uri,
                                mode:
                                LaunchMode.externalApplication,
                              );
                              if (!ok) {
                                // ignore: use_build_context_synchronously
                                ScaffoldMessenger.of(context)
                                    .showSnackBar(const SnackBar(
                                    content: Text(
                                        'Could not open the link')));
                              }
                            },
                            icon: const Icon(Icons.open_in_new, size: 16),
                            label: const Text('Open Paper'),
                          ),
                          const Spacer(),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Uri _normalizeUrl(String s) {
    final u = s.trim();
    final hasScheme =
        u.startsWith('http://') || u.startsWith('https://');
    return Uri.parse(hasScheme ? u : 'https://$u');
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.bookmark_border, size: 60, color: AppColors.lightText),
            const SizedBox(height: 16),
            Text(
              'No saved articles yet',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 8),
            Text(
              'Tap the heart icon on an article to save it here.',
              style: Theme.of(context)
                  .textTheme
                  .bodyLarge
                  ?.copyWith(color: AppColors.lightText),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
