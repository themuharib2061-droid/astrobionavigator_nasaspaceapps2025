import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../theme/app_colors.dart';
import '../widgets/category_picker.dart';

class EditProfilePage extends StatefulWidget {
  final String displayName;
  final String email;
  final String country;
  final Set<String> preferredKeys;
  final List<CategoryItem> allCategories;
  final Uint8List? avatarBytes;

  const EditProfilePage({
    super.key,
    required this.displayName,
    required this.email,
    required this.country,
    required this.preferredKeys,
    required this.allCategories,
    required this.avatarBytes,
  });

  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  late final TextEditingController _nameCtrl;
  late final TextEditingController _emailCtrl;
  late String _country;
  late Set<String> _selected; // local working copy
  Uint8List? _avatarBytes;

  static const List<String> _countries = [
    'Bangladesh',
    'India',
    // 'Pakistan',
    'Nepal',
    'Bhutan',
    'Sri Lanka',
    'USA',
    'UK',
    'Canada',
    'Australia',
  ];

  final _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(text: widget.displayName);
    _emailCtrl = TextEditingController(text: widget.email);
    _country = widget.country;
    _selected = {...widget.preferredKeys};
    _avatarBytes = widget.avatarBytes;
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickAvatar() async {
    final x = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (x == null) return;
    final bytes = await x.readAsBytes();
    setState(() => _avatarBytes = bytes);
  }

  void _toggle(String key) {
    setState(() {
      if (_selected.contains(key)) {
        _selected.remove(key);
      } else {
        if (_selected.length >= 3) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Pick up to 3 categories.')),
          );
          return;
        }
        _selected.add(key);
      }
    });
  }

  void _save() {
    Navigator.of(context).pop(<String, dynamic>{
      'displayName': _nameCtrl.text.trim(),
      'email': _emailCtrl.text.trim(),
      'country': _country,
      'preferred': _selected.toList(),
      'avatarBytes': _avatarBytes,
    });
  }

  @override
  Widget build(BuildContext context) {
    final avatar = _avatarBytes == null
        ? const CircleAvatar(radius: 40, child: Icon(Icons.person, size: 36))
        : CircleAvatar(radius: 40, backgroundImage: MemoryImage(_avatarBytes!));

    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Profile'),
        actions: [
          TextButton(
            onPressed: _save,
            child: const Text('Save', style: TextStyle(color: AppColors.accent)),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Avatar + change button
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.outline),
            ),
            child: Row(
              children: [
                avatar,
                const SizedBox(width: 16),
                ElevatedButton.icon(
                  onPressed: _pickAvatar,
                  icon: const Icon(Icons.upload),
                  label: const Text('Upload new photo'),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // Basic info
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.outline),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Basic Info', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 12),
                TextField(
                  controller: _nameCtrl,
                  decoration: InputDecoration(
                    labelText: 'Display name',
                    filled: true,
                    fillColor: AppColors.surface,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: AppColors.outline),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: AppColors.outline),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _emailCtrl,
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    labelText: 'Email',
                    filled: true,
                    fillColor: AppColors.surface,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: AppColors.outline),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: AppColors.outline),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: _country,
                  items: _countries
                      .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                      .toList(),
                  onChanged: (v) => setState(() => _country = v ?? _country),
                  decoration: InputDecoration(
                    labelText: 'Country',
                    filled: true,
                    fillColor: AppColors.surface,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: AppColors.outline),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: AppColors.outline),
                    ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // Preferred categories edit
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.outline),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text('Preferred Categories (max 3)',
                        style: Theme.of(context).textTheme.titleMedium),
                    const Spacer(),
                    Text('${_selected.length}/3',
                        style: Theme.of(context).textTheme.bodyMedium),
                  ],
                ),
                const SizedBox(height: 12),
                _ChipsGridEditable(
                  all: widget.allCategories,
                  selected: _selected,
                  onToggle: _toggle,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ChipsGridEditable extends StatelessWidget {
  final List<CategoryItem> all;
  final Set<String> selected;
  final ValueChanged<String> onToggle;

  const _ChipsGridEditable({
    required this.all,
    required this.selected,
    required this.onToggle,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (_, constraints) {
        final isWide = constraints.maxWidth > 900;
        final columns = isWide ? 3 : 2;
        const gap = 10.0;
        final itemWidth = (constraints.maxWidth - (columns - 1) * gap) / columns;

        return Wrap(
          spacing: gap,
          runSpacing: gap,
          children: all.map((c) {
            final on = selected.contains(c.key);
            return ConstrainedBox(
              constraints: BoxConstraints(maxWidth: itemWidth),
              child: FilterChip(
                selected: on,
                onSelected: (_) => onToggle(c.key),
                label: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(c.emoji),
                    const SizedBox(width: 8),
                    Flexible(child: Text(c.label, overflow: TextOverflow.ellipsis)),
                  ],
                ),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                backgroundColor: AppColors.surface,
                side: const BorderSide(color: AppColors.outline),
                selectedColor: AppColors.accent.withOpacity(0.18),
                labelStyle: TextStyle(
                  color: on ? AppColors.textPrimary : AppColors.textSecondary,
                  fontWeight: on ? FontWeight.w600 : FontWeight.w500,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
            );
          }).toList(),
        );
      },
    );
  }
}
