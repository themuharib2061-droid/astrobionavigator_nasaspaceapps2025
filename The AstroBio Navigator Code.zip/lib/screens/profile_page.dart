import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../theme/app_colors.dart';
import '../services/auth_service.dart';
import 'signup_step2_page.dart';
import 'login_page.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Profile')),
        body: Center(
          child: ElevatedButton(
            onPressed: () => Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(builder: (_) => const LoginPage()),
                  (route) => false,
            ),
            child: const Text('Log in'),
          ),
        ),
      );
    }

    final uid = user.id;
    final email = user.email ?? '';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        actions: [
          IconButton(
            tooltip: 'Sign out',
            onPressed: () async {
              await AuthService.signOut();
              if (!context.mounted) return;
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                    (route) => false,
              );
            },
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: StreamBuilder<Map<String, dynamic>?>(
        stream: AuthService.profileStream(uid),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final data = snap.data ?? {};
          final name = (data['display_name'] as String?)?.trim();
          final avatarUrl = data['avatar_url'] as String?;
          final prefs = (data['preferred_categories'] as List?)?.cast<String>() ?? const <String>[];

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              // Header
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.outline),
                ),
                child: Row(
                  children: [
                    _Avatar(avatarUrl: avatarUrl, fallbackName: name ?? email),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(name?.isNotEmpty == true ? name! : 'Unnamed',
                              style: Theme.of(context).textTheme.titleMedium),
                          const SizedBox(height: 4),
                          Text(email, style: Theme.of(context).textTheme.bodyMedium),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    FilledButton.icon(
                      onPressed: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => SignupStep2Page(uid: uid, email: email),
                          ),
                        );
                      },
                      icon: const Icon(Icons.tune),
                      label: const Text('Edit preferences'),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // Preferred categories
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.outline),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Preferred Categories', style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 10),
                    if (prefs.isEmpty)
                      Text('Not set yet. Tap "Edit preferences" to choose up to 3.',
                          style: Theme.of(context).textTheme.bodyMedium)
                    else
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: prefs.map((k) => Chip(label: Text(_labelForKey(k)))).toList(),
                      ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _Avatar extends StatelessWidget {
  final String? avatarUrl;
  final String fallbackName;
  const _Avatar({required this.avatarUrl, required this.fallbackName});

  @override
  Widget build(BuildContext context) {
    if (avatarUrl != null && avatarUrl!.isNotEmpty) {
      return CircleAvatar(radius: 28, backgroundImage: NetworkImage(avatarUrl!));
    }
    final initial = _initials(fallbackName);
    return CircleAvatar(
      radius: 28,
      backgroundColor: AppColors.accent.withOpacity(0.2),
      child: Text(
        initial,
        style: Theme.of(context).textTheme.titleMedium?.copyWith(
          color: AppColors.accent,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }

  String _initials(String s) {
    final parts = s.trim().split(RegExp(r'\s+'));
    if (parts.length >= 2) {
      return ('${parts[0].isNotEmpty ? parts[0][0] : ''}${parts[1].isNotEmpty ? parts[1][0] : ''}')
          .toUpperCase();
    }
    return s.isNotEmpty ? s[0].toUpperCase() : '?';
  }
}

String _labelForKey(String key) {
  const map = {
    'microgravity_biology':  'Microgravity Effects on Biology',
    'origin_of_life':        'Origin of Life & Prebiotic Chemistry',
    'microbial_space':       'Microbial Life in Space',
    'human_physiology':      'Human Physiology in Space',
    'space_agriculture':     'Space Agriculture & Synthetic Biology',
    'neuroscience_space':    'Neuroscience & Behavior in Space',
    'habitability':          'Planetary Environments & Habitability',
    'radiation_biology':     'Space Radiation Biology',
    'omics_space':           'Omics in Space',
    'experimental_platforms':'Experimental Platforms',
    'bioinformatics':        'Bioinformatics & Modeling',
    'earth_analogs':         'Earth Analogs for Astrobiology',
    'hazards_mitigation':    'Spaceflight Hazards & Mitigation',
    'life_detection':        'Life Detection & Biosignatures',
    'isru_biology':          'ISRU Biology',
    'exoplanet_atmospheres': 'Exoplanet Atmospheres',
    'astro_missions':        'Astrobiology Missions',
    'planetary_protection':  'Planetary Protection',
    'space_healthtech':      'Space Health Tech & Telemed',
    'ethics_policy':         'Ethics & Policy',
  };
  return map[key] ?? key;
}
