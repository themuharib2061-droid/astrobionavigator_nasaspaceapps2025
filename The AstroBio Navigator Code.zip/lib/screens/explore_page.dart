import 'dart:async';
import 'package:flutter/material.dart';
import '../services/paper_service.dart';          // PaperService + Paper + PaperX
import '../widgets/study_card.dart';             // has Summarize button via onSummarize
import '../widgets/summary_chat_sheet.dart' as summary;

class ExplorePage extends StatefulWidget {
  const ExplorePage({super.key});
  @override
  State<ExplorePage> createState() => _ExplorePageState();
}

class _ExplorePageState extends State<ExplorePage> {
  final _searchCtrl = TextEditingController();
  final _scroll = ScrollController();
  final _svc = PaperService();

  List<Paper> _items = [];
  String? _error;
  bool _loading = false;
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    // Also react if someone clears text with the clear button
    _searchCtrl.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchCtrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  // -------- search triggers --------
  void _onSearchChanged() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 450), () {
      _doSearch(_searchCtrl.text);
    });
  }

  Future<void> _doSearch(String raw) async {
    final keyword = raw.trim();
    if (keyword.isEmpty) {
      setState(() {
        _items = [];
        _error = null;
      });
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final papers = await _svc.searchPapers(keyword: keyword, limit: 20);
      if (!mounted) return;
      setState(() {
        _items = papers;
        _error = null;
      });
    } catch (e) {
      // You will see CORS/ClientException/HTTP body here
      if (!mounted) return;
      setState(() => _error = e.toString());
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Search failed: $e')),
      );
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  // -------- UI --------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Explore Papers', )),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _searchCtrl,
                    textInputAction: TextInputAction.search,
                    onSubmitted: _doSearch, // Enter key
                    decoration: InputDecoration(
                      hintText: 'Search by keyword…',
                      prefixIcon: const Icon(Icons.search),
                      suffixIcon: _searchCtrl.text.isEmpty
                          ? null
                          : IconButton(
                        tooltip: 'Clear',
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchCtrl.clear();
                          // listener will trigger debounce -> clears results
                        },
                      ),
                      border: const OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton.icon(
                  onPressed: () => _doSearch(_searchCtrl.text), // explicit tap
                  icon: const Icon(Icons.search),
                  label: const Text('Search'),
                ),
              ],
            ),
          ),
          if (_loading) const LinearProgressIndicator(minHeight: 2),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                _error!,
                style: TextStyle(color: Theme.of(context).colorScheme.error),
              ),
            ),
          Expanded(
            child: _items.isEmpty && !_loading
                ? const Center(child: Text('Type a keyword and search.'))
                : ListView.builder(
              controller: _scroll,
              itemCount: _items.length,
              itemBuilder: (_, i) {
                final p = _items[i];
                return StudyCard(
                  paper: p,
                  showSummarize: true,
                  onSummarize: () {
                    // If your sheet needs only context:
                    // summary.showSummaryChatSheet(context);

                    // If your sheet accepts an initial prompt/seed:
                    summary.showSummaryChatSheet(
                      context,
                      initial:
                      'Summarize this paper for me in key points.\n'
                          'Title: ${p.title}\n'
                          'Authors: ${p.authors}\n'
                          'Year: ${p.publishYear ?? ""}\n'
                          'Link: ${p.bestUrl ?? p.link}\n'
                          'Abstract: ${p.abstract}', articleTitle: '', articleUrl: '',
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
