import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../services/auth_service.dart';
import 'main_screen.dart';

class SignupStep2Page extends StatefulWidget {
  final String uid;
  final String email;
  const SignupStep2Page({super.key, required this.uid, required this.email});

  @override
  State<SignupStep2Page> createState() => _SignupStep2PageState();
}

class _SignupStep2PageState extends State<SignupStep2Page> {
  bool _saving = false;
  String? _error;

  // 20 user-friendly categories (keys are what we store)
  static const List<({String key, String label, String emoji})> _categories = [
    (key: 'microgravity_biology',  label: 'Microgravity Effects on Biology', emoji: '🧬'),
    (key: 'origin_of_life',        label: 'Origin of Life & Prebiotic Chemistry', emoji: '🌌'),
    (key: 'microbial_space',       label: 'Microbial Life in Space', emoji: '🧫'),
    (key: 'human_physiology',      label: 'Human Physiology in Space', emoji: '👩‍🚀'),
    (key: 'space_agriculture',     label: 'Space Agriculture & Synthetic Biology', emoji: '🌱'),
    (key: 'neuroscience_space',    label: 'Neuroscience & Behavior in Space', emoji: '🧠'),
    (key: 'habitability',          label: 'Planetary Environments & Habitability', emoji: '🪐'),
    (key: 'radiation_biology',     label: 'Space Radiation Biology', emoji: '🔬'),
    (key: 'omics_space',           label: 'Omics in Space', emoji: '🧬'),
    (key: 'experimental_platforms',label: 'Experimental Platforms', emoji: '🧪'),
    (key: 'bioinformatics',        label: 'Bioinformatics & Modeling', emoji: '👾'),
    (key: 'earth_analogs',         label: 'Earth Analogs for Astrobiology', emoji: '🌍'),
    (key: 'hazards_mitigation',    label: 'Spaceflight Hazards & Mitigation', emoji: '🧯'),
    (key: 'life_detection',        label: 'Life Detection & Biosignatures', emoji: '🌌'),
    (key: 'isru_biology',          label: 'ISRU Biology', emoji: '⚗️'),
    (key: 'exoplanet_atmospheres', label: 'Exoplanet Atmospheres', emoji: '🌫️'),
    (key: 'astro_missions',        label: 'Astrobiology Missions', emoji: '🛰️'),
    (key: 'planetary_protection',  label: 'Planetary Protection', emoji: '🛡️'),
    (key: 'space_healthtech',      label: 'Space Health Tech & Telemed', emoji: '🩺'),
    (key: 'ethics_policy',         label: 'Ethics & Policy', emoji: '⚖️'),
  ];

  final List<String> _selected = [];

  void _toggle(String key) {
    setState(() {
      if (_selected.contains(key)) {
        _selected.remove(key);
      } else if (_selected.length < 3) {
        _selected.add(key);
      }
    });
  }

  Future<void> _submit() async {
    setState(() { _saving = true; _error = null; });
    try {
      await AuthService.setPreferredCategories(uid: widget.uid, categories: _selected);
      if (!mounted) return;
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const MainScreen()),
            (route) => false,
      );
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final canSubmit = _selected.isNotEmpty && _selected.length <= 3;

    return Scaffold(
      appBar: AppBar(title: const Text('Sign up — Step 2')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 760),
          child: Card(
            color: AppColors.surface,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
              side: const BorderSide(color: AppColors.outline),
            ),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (_error != null)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      margin: const EdgeInsets.only(bottom: 8),
                      decoration: BoxDecoration(
                        color: Colors.red.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.red.withOpacity(0.4)),
                      ),
                      child: Text(_error!, style: const TextStyle(color: Colors.redAccent)),
                    ),
                  Text('Pick your top 3 research interests',
                      style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 8),
                  Text(
                    _selected.isEmpty
                        ? 'You can select up to 3.'
                        : 'Selected: ${_selected.length} / 3',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  const SizedBox(height: 16),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: _categories.map((c) {
                      final selected = _selected.contains(c.key);
                      return ChoiceChip(
                        label: Text('${c.emoji}  ${c.label}'),
                        selected: selected,
                        onSelected: (_) => _toggle(c.key),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: (!canSubmit || _saving) ? null : _submit,
                      child: _saving
                          ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Text('Submit'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
