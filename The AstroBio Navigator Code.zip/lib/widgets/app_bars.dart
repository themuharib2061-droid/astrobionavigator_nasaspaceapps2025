// lib/widgets/app_bars.dart
import 'package:flutter/material.dart';

class AppBars {
  /// AppBar with your logo + title, forced white text/icons.
  /// Usage: appBar: AppBars.logo('Explore Papers')
  static PreferredSizeWidget logo(
      String title, {
        List<Widget>? actions,
        double logoSize = 22,
        EdgeInsetsGeometry logoPadding = const EdgeInsets.only(right: 8),
        String assetPath = 'assets/brand/logo.png',
      }) {
    return AppBar(
      // Makes title text & default icons white
      foregroundColor: Colors.white,
      titleTextStyle: const TextStyle(
        color: Colors.white,
        fontSize: 20,
        fontWeight: FontWeight.w600,
      ),
      toolbarTextStyle: const TextStyle(color: Colors.white),
      iconTheme: const IconThemeData(color: Colors.white),
      actionsIconTheme: const IconThemeData(color: Colors.white),

      // Keep your existing background color from theme (no UI change)
      // backgroundColor: Theme.of(context).appBarTheme.backgroundColor,

      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: logoPadding,
            child: Image.asset(
              assetPath,
              height: logoSize,
              // If you want to tint the logo white as well, uncomment:
              // color: Colors.white,
            ),
          ),
          const SizedBox(width: 2),
          Flexible(
            child: Text(
              title,
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
            ),
          ),
        ],
      ),
      actions: actions,
    );
  }
}
