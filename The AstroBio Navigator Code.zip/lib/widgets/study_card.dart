import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/paper_service.dart';           // Paper + PaperX (bestUrl)
import '../services/favorites_service.dart';      // your existing favorites service

class StudyCard extends StatelessWidget {
  final Paper paper;
  final bool showSummarize;
  final VoidCallback? onSummarize;

  const StudyCard({
    super.key,
    required this.paper,
    this.showSummarize = true,
    this.onSummarize,
  });

  @override
  Widget build(BuildContext context) {
    final yearText = paper.publishYear?.toString();
    final canOpen = paper.bestUrl != null && paper.bestUrl!.trim().isNotEmpty;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Title + (right column: year chip + heart)
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Text(
                    paper.title,
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (yearText != null)
                      Chip(
                        label: Text(yearText),
                        visualDensity: VisualDensity.compact,
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                    const SizedBox(height: 6),
                    _FavButton(paper: paper),   // ← heart button
                  ],
                ),
              ],
            ),
            const SizedBox(height: 6),
            if (paper.authors.isNotEmpty)
              Text(paper.authors, style: Theme.of(context).textTheme.bodySmall),
            if (paper.publicationInfo.isNotEmpty)
              Text(paper.publicationInfo, style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              children: [
                TextButton.icon(
                  onPressed: canOpen ? () => _openPaper(context) : null,
                  icon: const Icon(Icons.open_in_new, size: 16),
                  label: const Text('Open Paper'),
                ),
                if (showSummarize)
                  TextButton.icon(
                    onPressed: onSummarize,
                    icon: const Icon(Icons.summarize, size: 16),
                    label: const Text('Summarize'),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _openPaper(BuildContext context) async {
    final raw = paper.bestUrl;
    if (raw == null || raw.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No link available for this paper')),
      );
      return;
    }
    final uri = _normalizeUrl(raw);
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not open the link')),
      );
    }
  }

  Uri _normalizeUrl(String s) {
    final u = s.trim();
    final hasScheme = u.startsWith('http://') || u.startsWith('https://');
    return Uri.parse(hasScheme ? u : 'https://$u');
  }
}

/// Small, self-contained favorite button used by the card.
/// It asks FavoritesService if the paper is saved (by URL) and toggles it.
class _FavButton extends StatefulWidget {
  final Paper paper;
  const _FavButton({required this.paper});

  @override
  State<_FavButton> createState() => _FavButtonState();
}

class _FavButtonState extends State<_FavButton> {
  bool _saved = false;
  bool _initDone = false;

  String get _key =>
      (widget.paper.pdfLink != null && widget.paper.pdfLink!.trim().isNotEmpty)
          ? widget.paper.pdfLink!.trim()
          : widget.paper.link.trim();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final saved = await FavoritesService.instance.isSavedByUrl(_key);
      if (mounted) setState(() { _saved = saved; _initDone = true; });
    } catch (_) {
      if (mounted) setState(() { _initDone = true; });
    }
  }

  Future<void> _toggle() async {
    try {
      if (_saved) {
        await FavoritesService.instance.removeByUrl(_key);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Removed from Saved')),
        );
      } else {
        await FavoritesService.instance.savePaper(widget.paper);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Saved to Saved Articles')),
        );
      }
      if (mounted) setState(() => _saved = !_saved);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not update favorites: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_initDone) {
      return const SizedBox(
        height: 32,
        width: 32,
        child: Padding(
          padding: EdgeInsets.all(6),
          child: CircularProgressIndicator(strokeWidth: 2),
        ),
      );
    }
    return IconButton(
      tooltip: _saved ? 'Unsave' : 'Save',
      constraints: const BoxConstraints(minHeight: 32, minWidth: 32),
      padding: EdgeInsets.zero,
      onPressed: _toggle,
      icon: Icon(_saved ? Icons.favorite : Icons.favorite_border),
      color: _saved ? Theme.of(context).colorScheme.secondary : null,
    );
  }
}
