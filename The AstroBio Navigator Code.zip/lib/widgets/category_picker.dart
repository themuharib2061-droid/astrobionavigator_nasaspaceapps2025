import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

@immutable
class CategoryItem {
  final String key;   // backend slug
  final String label; // UI label
  final String emoji; // small icon/emoji

  const CategoryItem(this.key, this.label, this.emoji);
}

class CategoryPicker extends StatefulWidget {
  final String? selectedKey;
  final ValueChanged<String?> onChanged;

  /// Provide your full list here (20 items).
  final List<CategoryItem> categories;

  /// How many to show in the horizontal quick ribbon.
  final int featuredCount;

  const CategoryPicker({
    super.key,
    required this.selectedKey,
    required this.onChanged,
    required this.categories,
    this.featuredCount = 8,
  });

  @override
  State<CategoryPicker> createState() => _CategoryPickerState();
}

class _CategoryPickerState extends State<CategoryPicker> {
  bool _showAll = false;

  @override
  Widget build(BuildContext context) {
    final featured = widget.categories.take(widget.featuredCount).toList();
    final all = widget.categories;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Categories', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),

        // Quick Picks (horizontal)
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: [
              _buildChoiceChip(
                keyValue: null,
                emoji: '✨',
                label: 'All',
              ),
              const SizedBox(width: 8),
              ...featured.map((c) => Padding(
                padding: const EdgeInsets.only(right: 8),
                child: _buildChoiceChip(
                  keyValue: c.key,
                  emoji: c.emoji,
                  label: c.label,
                ),
              )),
            ],
          ),
        ),

        const SizedBox(height: 12),

        // Expand / collapse for ALL categories
        AnimatedCrossFade(
          crossFadeState:
          _showAll ? CrossFadeState.showFirst : CrossFadeState.showSecond,
          duration: const Duration(milliseconds: 220),
          firstChild: _AllCategoriesGrid(
            selectedKey: widget.selectedKey,
            onChanged: widget.onChanged,
            categories: all,
          ),
          secondChild: const SizedBox.shrink(),
        ),

        Align(
          alignment: Alignment.centerLeft,
          child: TextButton.icon(
            onPressed: () => setState(() => _showAll = !_showAll),
            icon: Icon(_showAll ? Icons.expand_less : Icons.expand_more),
            label: Text(_showAll ? 'Show less' : 'Show all'),
          ),
        ),
      ],
    );
  }

  Widget _buildChoiceChip({
    required String? keyValue,
    required String emoji,
    required String label,
  }) {
    final selected = widget.selectedKey == keyValue;
    return ChoiceChip(
      selected: selected,
      onSelected: (_) => widget.onChanged(keyValue),
      label: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(emoji),
          const SizedBox(width: 6),
          Flexible(child: Text(label, overflow: TextOverflow.ellipsis)),
        ],
      ),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      backgroundColor: Colors.transparent,
      side: const BorderSide(color: AppColors.outline),
      selectedColor: AppColors.accent.withOpacity(0.18),
      labelStyle: TextStyle(
        color: selected ? AppColors.textPrimary : AppColors.textSecondary,
        fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
      ),
      shape: const StadiumBorder(),
    );
  }
}

class _AllCategoriesGrid extends StatelessWidget {
  final String? selectedKey;
  final ValueChanged<String?> onChanged;
  final List<CategoryItem> categories;

  const _AllCategoriesGrid({
    required this.selectedKey,
    required this.onChanged,
    required this.categories,
  });

  @override
  Widget build(BuildContext context) {
    // Responsive columns: 3 on wide screens, 2 on smaller
    final width = MediaQuery.of(context).size.width;
    final columns = width > 900 ? 3 : 2;

    return LayoutBuilder(
      builder: (_, __) {
        return Wrap(
          spacing: 10,
          runSpacing: 10,
          children: categories.map((c) {
            final selected = selectedKey == c.key;
            return ConstrainedBox(
              constraints: BoxConstraints(
                // Each item roughly 1/N width minus gaps
                maxWidth: (width - 32 - (columns - 1) * 10) / columns,
              ),
              child: ChoiceChip(
                selected: selected,
                onSelected: (_) => onChanged(c.key),
                label: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(c.emoji),
                    const SizedBox(width: 8),
                    Flexible(child: Text(c.label, overflow: TextOverflow.ellipsis)),
                  ],
                ),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                backgroundColor: AppColors.surface,
                side: const BorderSide(color: AppColors.outline),
                selectedColor: AppColors.accent.withOpacity(0.18),
                labelStyle: TextStyle(
                  color: selected ? AppColors.textPrimary : AppColors.textSecondary,
                  fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
            );
          }).toList(),
        );
      },
    );
  }
}
