import 'package:flutter/material.dart';
import '../services/summary_chat_api.dart';

Future<void> showSummaryChatSheet(
    BuildContext context, {
      String? url,          // new name
      String? articleUrl,   // legacy name supported too
      String? initial,
      String? articleTitle, // typed, optional
    }) async {
  // Prefer `url`, fall back to `articleUrl`
  final effectiveUrl = (url != null && url.trim().isNotEmpty)
      ? url.trim()
      : (articleUrl != null && articleUrl.trim().isNotEmpty ? articleUrl.trim() : null);

  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (_) => _SummaryChatBody(
      url: effectiveUrl,
      initial: initial,
      articleTitle: articleTitle,
    ),
  );
}

class _SummaryChatBody extends StatefulWidget {
  final String? url;
  final String? initial;
  final String? articleTitle;
  const _SummaryChatBody({this.url, this.initial, this.articleTitle});

  @override
  State<_SummaryChatBody> createState() => _SummaryChatBodyState();
}

class _SummaryChatBodyState extends State<_SummaryChatBody> {
  String? _error;
  String? _summary;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _kickoff();
  }

  Future<void> _kickoff() async {
    final u = widget.url;
    if (u == null || u.trim().isEmpty) return;
    setState(() { _loading = true; _error = null; });
    try {
      final s = await SummaryChatApi.summarizeUrl(u.trim());
      if (!mounted) return;
      setState(() => _summary = s);
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.articleTitle ?? 'Summary Chat')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
            ? Text('Error: $_error', style: TextStyle(color: Theme.of(context).colorScheme.error))
            : SingleChildScrollView(child: Text(_summary ?? 'Paste a URL or ask a question…')),
      ),
    );
  }
}
