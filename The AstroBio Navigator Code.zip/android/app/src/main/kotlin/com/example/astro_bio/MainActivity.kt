package com.example.astro_bio

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
